<?php
/**
 * Created by PhpStorm.
 * User: webwerks1
 * Date: 21/3/16
 * Time: 3:42 PM
 */
var_dump($_POST);
//echo $_POST('x');
?>